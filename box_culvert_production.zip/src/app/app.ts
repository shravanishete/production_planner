import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ProductionTable } from './components/production-table/production-table';
import { Dashboard } from './components/dashboard/dashboard';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,ProductionTable,Dashboard],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('box-culvert-plannerp');
}
