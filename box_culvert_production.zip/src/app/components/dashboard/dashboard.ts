import { Component, HostListener } from '@angular/core';
import { ProductionTable } from '../production-table/production-table';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import Swal from 'sweetalert2';
import data from '../../../assests/data.json';
import { ProductionAvailability } from '../production-availability/production-availability';
import { Header } from '../header/header';

export interface FormRow {
  selectedProject: any | null;
  selectedElement: any | null;
  selectedBed: any | null;
  quantity: number | null;
  filteredElements: any[];
  openDropdown: 'project' | 'element' | 'bed' | null;
  qtyError: string;
  dropdownRect: { top: number; left: number; width: number } | null;
  remainingToday?: { day: number; remaining: number; }
   similarProjectSuggestions?: { projectName: string; size: string; availableQty: number }[];
}

@Component({
  selector: 'app-dashboard',
  imports: [FormsModule, CommonModule, ProductionTable, ProductionAvailability,Header],
  standalone: true,
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css'],
})
export class Dashboard {
  projects = data.projects;
  beds = data.beds;
  showAvailability = true;
  formRow: FormRow = this.emptyFormRow();
  dialogOpen = false;

  showTable = false;
  tableProjects: any[] = [];
  tableElements: any[] = [];
  tableBeds: any[] = [];
  tablePlanRows: any[] = [];

  private emptyFormRow(): FormRow {
    return {
      selectedProject: null,
      selectedElement: null,
      selectedBed: null,
      quantity: null,
      filteredElements: [],
      openDropdown: null,
      qtyError: '',
      dropdownRect: null,
    };
  }

  openDialog() {
    this.formRow = this.emptyFormRow();
    this.dialogOpen = true;
  }

  closeDialog() {
    this.dialogOpen = false;
    this.formRow.openDropdown = null;
  }

  @HostListener('document:click')
  onDocumentClick() {
    this.formRow.openDropdown = null;
  }

  toggleFormDropdown(which: 'project' | 'element' | 'bed', event: Event) {
    event.stopPropagation();
    const trigger = event.currentTarget as HTMLElement;
    const rect = trigger.getBoundingClientRect();
    if (this.formRow.openDropdown === which) {
      this.formRow.openDropdown = null;
      this.formRow.dropdownRect = null;
    } else {
      this.formRow.openDropdown = which;
      this.formRow.dropdownRect = { top: rect.bottom + 3, left: rect.left, width: rect.width };
    }
  }

  selectFormProject(project: any, event: Event) {
    event.stopPropagation();
    this.formRow.selectedProject = project;
    this.formRow.selectedElement = null;
    this.formRow.filteredElements = project.elements;
    this.formRow.openDropdown = null;
  }

  selectFormElement(element: any, event: Event) {
    event.stopPropagation();
    this.formRow.selectedElement = element;
    this.formRow.openDropdown = null;
    this.updateRemainingToday();
  }

  selectFormBed(bed: any, event: Event) {
    event.stopPropagation();
    this.formRow.selectedBed = bed;
    this.formRow.openDropdown = null;
    this.updateRemainingToday();
  }

  // onFormQtyChange() {
  //   const q = this.formRow.quantity;
  //   const maxQty = this.formRow.selectedElement?.quantity ?? 200;

  //   if (q === null || q === undefined) {
  //     this.formRow.qtyError = '';
  //   } else if (q < 1) {
  //     this.formRow.qtyError = 'Quantity must be at least 1.';
  //   } else if (q > maxQty) {
  //     this.formRow.qtyError = `Quantity cannot exceed available quantity (${maxQty}).`;
  //   } else {
  //     this.formRow.qtyError = '';
  //   }
  // }
onFormQtyChange() {
  const q = this.formRow.quantity;
   const maxQty = this.formRow.selectedElement?.quantity ?? 200;
  const f = this.formRow;

  const elementTotalQty = f.selectedElement?.quantity ?? 200;
  const alreadyPlanned = f.selectedProject && f.selectedElement
    ? this.tablePlanRows
        .filter(r => r.project === f.selectedProject.name && r.size === f.selectedElement.size)
        .reduce((sum, r) => sum + r.quantity, 0)
    : 0;
  const remainingQty = elementTotalQty - alreadyPlanned;

  if (q === null || q === undefined) {
    f.qtyError = '';
  } else if (q < 1) {
    f.qtyError = 'Quantity must be at least 1.';
  }  else if (q > maxQty) {
       this.formRow.qtyError = `Quantity cannot exceed available quantity (${maxQty}).`;
  }
  else if (q > remainingQty) {
    f.qtyError = `Only ${remainingQty} units remaining for ${f.selectedProject?.name} — ${f.selectedElement?.size}.`;
  } else {
    f.qtyError = '';
  }
}
  onReset() {
    this.showTable = false;
    this.tablePlanRows = [];
    this.tableBeds = [];
    this.tableProjects = [];
    this.tableElements = [];
    this.showAvailability = true;
  }

  onGenerate() {
    this.showAvailability = false;
    const f = this.formRow;
    const missing: string[] = [];

    if (!f.selectedProject) missing.push('Project');
    if (!f.selectedElement) missing.push('Element');
    if (!f.selectedBed) missing.push('Bed');
    if (!f.quantity || f.quantity <= 0) {
      missing.push('Quantity');
    } else {
      const maxQty = f.selectedElement?.quantity ?? 200;
      if (f.quantity > maxQty) {
        Swal.fire({
          toast: true,
          position: 'top-end',
          icon: 'error',
          title: `Quantity cannot exceed available (${maxQty})`,
          showConfirmButton: false,
          timer: 2500,
          timerProgressBar: true,
          didOpen: (toast) => {
            (toast.closest('.swal2-container') as HTMLElement).style.zIndex = '99999';
          }
        });
        return;
      }
    }

    if (missing.length > 0) {
      Swal.fire({
        toast: true,
        position: 'top-end',
        icon: 'warning',
        title: `Please fill: ${missing.join(', ')}`,
        showConfirmButton: false,
        timer: 2500,
        timerProgressBar: true,
        didOpen: (toast) => {
          (toast.closest('.swal2-container') as HTMLElement).style.zIndex = '99999';
        }
      });
      return;
    }

    this.tablePlanRows = [...this.tablePlanRows, {
       id: `${f.selectedElement.id}_${Date.now()}`,
      project: f.selectedProject.name,
      type: f.selectedElement.type,
      size: f.selectedElement.size,
      quantity: f.quantity,
      bed: f.selectedBed,
    }];

    if (!this.tableBeds.find(b => b.name === f.selectedBed.name)) {
      this.tableBeds = [...this.tableBeds, f.selectedBed];
    }

    this.showTable = false;
    this.closeDialog();

    Swal.fire({
      toast: true,
      position: 'top-end',
      icon: 'success',
      title: 'Entry added to plan',
      showConfirmButton: false,
      timer: 3000,
      timerProgressBar: true,
      didOpen: (toast) => {
        (toast.closest('.swal2-container') as HTMLElement).style.zIndex = '99999';
      }
    });

    this.showTable = true;
  }

  // updateRemainingToday() {
  //   const f = this.formRow;

  //   if (!f.selectedBed || !f.selectedElement) {
  //     f.remainingToday = undefined;
  //     return;
  //   }

  //   const size = f.selectedElement.size;
  //   const bedName = f.selectedBed.name;
  //   const dailyCap = f.selectedBed.capacityPerDay?.[size] ?? 0;
  //   const maxDays = 20;

  //   const table: any[] = this.tablePlanRows.map(r => ({
  //     size: r.size,
  //     bedName: r.bed?.name ?? '',
  //     bed: r.bed,
  //     remaining: r.quantity,
  //   }));
   
  //   const bedLastDay: { [bed: string]: number } = {};

  //   const allocated: { [key: string]: number } = {};

  //   table.forEach((row, index) => {
  //     const rowBedName = row.bedName;
  //     const rowSize = row.size;
  //     const rowCap = row.bed?.capacityPerDay?.[rowSize] ?? 0;

  //     let day = bedLastDay[rowBedName] ?? 1;

  //     while (row.remaining > 0 && day <= maxDays) {
  //       const key = `${rowBedName}|${rowSize}|d${day}`;
  //       const usedToday = allocated[key] ?? 0;
  //       const capLeft = rowCap - usedToday;

  //       if (capLeft > 0) {
  //         const alloc = Math.min(row.remaining, capLeft);
  //         allocated[key] = usedToday + alloc;
  //         row.remaining -= alloc;

  //         if (!bedLastDay[rowBedName] || day > bedLastDay[rowBedName]) {
  //           bedLastDay[rowBedName] = day;
  //         }
  //       }

  //       day++;
  //     }
  //   });
  //   const startDay = bedLastDay[bedName] ?? 1;

  //   for (let d = startDay; d <= maxDays; d++) {
  //     const key = `${bedName}|${size}|d${d}`;
  //     const usedToday = allocated[key] ?? 0;
  //     const remaining = dailyCap - usedToday;

  //     if (remaining > 0) {
  //       f.remainingToday = { day: d, remaining };
  //       return;
  //     }
  //   }
  //   f.remainingToday = { day: maxDays, remaining: 0 };
  // }

  //working
  updateRemainingToday() {
  const f = this.formRow;

  if (!f.selectedBed || !f.selectedElement) {
    f.remainingToday = undefined;
    f.similarProjectSuggestions = undefined;
    return;
  }

  const size = f.selectedElement.size;
  const bedName = f.selectedBed.name;
  const dailyCap = f.selectedBed.capacityPerDay?.[size] ?? 0;
  const maxDays = 20;

  const table: any[] = this.tablePlanRows.map(r => ({
    size: r.size,
    bedName: r.bed?.name ?? '',
    bed: r.bed,
    remaining: r.quantity,
  }));

  const bedLastDay: { [bed: string]: number } = {};
  const allocated: { [key: string]: number } = {};

  table.forEach((row) => {
    const rowBedName = row.bedName;
    const rowSize = row.size;
    const rowCap = row.bed?.capacityPerDay?.[rowSize] ?? 0;

    let day = bedLastDay[rowBedName] ?? 1;

    while (row.remaining > 0 && day <= maxDays) {
      const key = `${rowBedName}|${rowSize}|d${day}`;
      const usedToday = allocated[key] ?? 0;
      const capLeft = rowCap - usedToday;

      if (capLeft > 0) {
        const alloc = Math.min(row.remaining, capLeft);
        allocated[key] = usedToday + alloc;
        row.remaining -= alloc;
        if (!bedLastDay[rowBedName] || day > bedLastDay[rowBedName]) {
          bedLastDay[rowBedName] = day;
        }
      }
      day++;
    }
  });

  const startDay = bedLastDay[bedName] ?? 1;
  let foundRemaining = false;

  for (let d = startDay; d <= maxDays; d++) {
    const key = `${bedName}|${size}|d${d}`;
    const usedToday = allocated[key] ?? 0;
    const remaining = dailyCap - usedToday;

    if (remaining > 0) {
      f.remainingToday = { day: d, remaining };
      foundRemaining = true;
      break;
    }
  }

  if (!foundRemaining) {
    f.remainingToday = { day: maxDays, remaining: 0 };
  }

  
  const currentProjectName = f.selectedProject?.name;

const currentSize = size;


const currentProjectElemQty = f.selectedElement?.quantity ?? 0;


const alreadyPlannedForCurrent = this.tablePlanRows
  .filter(r => r.project === currentProjectName && r.size === currentSize)
  .reduce((sum: number, r: any) => sum + r.quantity, 0);

const currentProjectExhausted = alreadyPlannedForCurrent >= currentProjectElemQty;

if (!currentProjectExhausted) {
  f.similarProjectSuggestions = undefined;
  return;
}


const suggestions = this.projects
  .filter(p => p.name !== currentProjectName)
  .map(p => {
    const matchingElem = p.elements?.find((e: any) => e.size === currentSize);
    if (!matchingElem) return null;

    const alreadyPlanned = this.tablePlanRows
      .filter(r => r.project === p.name && r.size === currentSize)
      .reduce((sum: number, r: any) => sum + r.quantity, 0);

    const availableQty = matchingElem.quantity - alreadyPlanned
    if (availableQty <= 0) return null;

    return { projectName: p.name, size: currentSize, availableQty };
  })
  .filter(Boolean) as { projectName: string; size: string; availableQty: number }[];

f.similarProjectSuggestions = suggestions.length > 0 ? suggestions : undefined;

}





getAlreadyPlanned(projectName: string, size: string): number {
  if (!projectName || !size) return 0;
  return this.tablePlanRows
    .filter(r => r.project === projectName && r.size === size)
    .reduce((sum, r) => sum + r.quantity, 0);
}

get isCurrentProjectQtyFull(): boolean {
  const f = this.formRow;
  if (!f.selectedProject || !f.selectedElement) return false;

  const currentProjectElemQty = f.selectedElement?.quantity ?? 0;
  const alreadyPlanned = this.tablePlanRows
    .filter(r => r.project === f.selectedProject.name && r.size === f.selectedElement.size)
    .reduce((sum, r) => sum + r.quantity, 0);

  return alreadyPlanned >= currentProjectElemQty;
}

get isAllProjectsQtyFull(): boolean {
  const f = this.formRow;
  if (!f.selectedElement) return false;

  const size = f.selectedElement.size;
  const type = f.selectedElement.type;

  return this.projects.every(p => {
    const elem = p.elements?.find((e: any) => e.size === size && e.type === type);
    if (!elem) return true; 

    const alreadyPlanned = this.tablePlanRows
      .filter(r => r.project === p.name && r.size === size)
      .reduce((sum: number, r: any) => sum + r.quantity, 0);

    return alreadyPlanned >= elem.quantity;
  });
}
onPlanRowDeleted(rowId: string) {
  this.tablePlanRows = this.tablePlanRows.filter(r => r.id !== rowId);
  this.updateRemainingToday();
}
}