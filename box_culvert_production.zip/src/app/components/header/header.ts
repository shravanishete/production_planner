import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-header',
  imports: [CommonModule],
  standalone:true,
  templateUrl: './header.html',
  styleUrl: './header.css',
})
export class Header {
 @Input() title: string = '';
  @Input() showReset: boolean = false;
  @Input() showAddPlan: boolean = true;

  @Output() resetClicked = new EventEmitter<void>();
  @Output() addPlanClicked = new EventEmitter<void>();
}
