import { Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-chatbot',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './chatbot.html',
  styleUrl: './chatbot.css',
})
export class Chatbot {
  @Input() tableRows: any[] = [];
  @Input() projects: any[] = [];

  isOpen: boolean = false;
  userInput: string = '';
  messages: any[] = [];

  getGreeting(): string {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good Morning 🌤️';
    if (hour < 17) return 'Good Afternoon ☀️';
    return 'Good Evening 🌙';
  }


  toggleChat() {
    this.isOpen = !this.isOpen;

    if (this.isOpen) {
      this.messages = [];
      this.userInput = '';

      setTimeout(() => {
        this.messages.push({ sender: 'bot', text: `Hi! ${this.getGreeting()} 👋` });

        setTimeout(() => {
          this.messages.push({
            sender: 'bot',
            text: 'How can I help you with production?\n\nTry:\n• Remaining capacity\n• Acquired qty\n• List projects'
          });
          this.scrollToBottom();
        }, 600);
      }, 250);
    }
  }

  quickAsk(text: string) {
    this.userInput = text;
    this.sendMessage();
  }


  detectIntent(text: string): string {
    text = text.toLowerCase();
    if (text.includes('remaining') || text.includes('capacity') || text.includes('left')) return 'REMAINING';
    if (text.includes('acquired') || text.includes('scheduled') || text.includes('done') || text.includes('completed')) return 'ACQUIRED';
    if (text.includes('today')) return 'TODAY';
    if (text.includes('target')) return 'TARGET';
    if (text.includes('project') || text.includes('list')) return 'PROJECTS';
    return 'UNKNOWN';
  }

  extractProjectName(text: string): string | null {
    if (!this.tableRows?.length) return null;
    const lower = text.toLowerCase();
    const projectNames = [...new Set(this.tableRows.map(r => r.project as string))];
    return projectNames.find(name => lower.includes(name.toLowerCase())) ?? null;
  }

  
  getResponse(intent: string, rawText: string): string {
    const rows: any[] = this.tableRows ?? [];

    if (!rows.length) {
      return 'No production data available yet. Please add a plan first.';
    }

    const mentionedProject = this.extractProjectName(rawText);

    switch (intent) {

      case 'REMAINING': {
        const targetRows = mentionedProject
          ? rows.filter(r => r.project?.toLowerCase() === mentionedProject.toLowerCase())
          : rows;

        if (!targetRows.length) return `No data found for project "${mentionedProject}".`;

        const lines = targetRows.map(r => {
          const projectQty: number = r.projectElemQty ?? r.qty ?? 0;
          const entered: number   = r.totalEntered    ?? r.qty ?? 0;
          const remaining: number = Math.max(0, projectQty - entered);
          return `• ${r.project} | ${r.product} (${r.bed}): ${remaining} remaining`;
        });

        const header = mentionedProject
          ? `Remaining for "${mentionedProject}":`
          : 'Remaining capacity — all projects:';
        return `${header}\n${lines.join('\n')}`;
      }

      case 'ACQUIRED': {
        const targetRows = mentionedProject
          ? rows.filter(r => r.project?.toLowerCase() === mentionedProject.toLowerCase())
          : rows;

        if (!targetRows.length) return `No data found for project "${mentionedProject}".`;

        const lines = targetRows.map(r => {
          const scheduled: number = r.scheduledQty ?? r.qty ?? 0;
          const total: number     = r.projectElemQty ?? r.qty ?? 0;
          const pct = total > 0 ? Math.round((scheduled / total) * 100) : 0;
          return `• ${r.project} | ${r.product} (${r.bed}): ${scheduled}/${total} (${pct}%)`;
        });

        const header = mentionedProject
          ? `Acquired for "${mentionedProject}":`
          : 'Acquired qty — all projects:';
        return `${header}\n${lines.join('\n')}`;
      }

      case 'PROJECTS': {
        const names = [...new Set(rows.map(r => r.project))];
        return `Active projects:\n${names.map(n => `• ${n}`).join('\n')}`;
      }

      case 'TODAY':
        return `Today's total scheduled qty: ${rows.reduce((s, r) => s + (r.scheduledQty ?? 0), 0)}`;

      case 'TARGET':
        return `Total target qty across all plans: ${rows.reduce((s, r) => s + (r.qty ?? 0), 0)}`;

      default:
        return "I didn't get that. Try:\n• \"remaining capacity\"\n• \"acquired qty\"\n• \"list projects\"\n\nOr mention a project name!";
    }
  }


  sendMessage() {
    if (!this.userInput.trim()) return;

    const userText = this.userInput;
    this.messages.push({ sender: 'user', text: userText });

    const intent = this.detectIntent(userText);
    const reply  = this.getResponse(intent, userText);

    setTimeout(() => {
      this.messages.push({ sender: 'bot', text: reply });
      this.scrollToBottom();
    }, 300);

    this.userInput = '';
  }

  scrollToBottom() {
    setTimeout(() => {
      const box = document.querySelector('.chatbox');
      if (box) box.scrollTop = box.scrollHeight;
    }, 50);
  }
}