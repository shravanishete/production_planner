import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import * as XLSX from 'xlsx-js-style';
import { MatIconModule } from '@angular/material/icon';
import { GanttProduction } from '../gantt-production/gantt-production';
import { FormsModule } from '@angular/forms';
import { Chatbot } from '../chatbot/chatbot';
@Component({
  selector: 'app-production-table',
  standalone: true,
  imports: [CommonModule, MatIconModule,GanttProduction,FormsModule,Chatbot ],
  templateUrl: './production-table.html',
  styleUrl: './production-table.css',
})
export class ProductionTable implements OnChanges {
  @Input() projects: any[] = [];
  @Input() elements: any[] = [];
  @Input() beds: any[] = [];
  @Input() quantity: number | null = null;
  @Input() planRows: any[] = [];
  @Output() rowDeleted = new EventEmitter<string>(); 
  searchText: string= '';
  dayColumns: string[] = [];
  showGantt: boolean = false;
  tableRows: any[] = [];
  overCapacityWarnings: { project: string; product: string; bed: string; requestedQty: number }[] =
    [];
  ngOnChanges(changes: SimpleChanges) {
    if (this.planRows?.length && this.beds?.length) {
      this.allocateProduction();
    }
  }
// old one
  allocateProduction() {
    debugger
    const maxDays = 20;

    const table: any[] = this.planRows.map((r) => ({
       id: r.id,
      project: r.project,
      product: `${r.type} ${r.size}`,
      size: r.size,
      qty: r.quantity,
      remaining: r.quantity,
      bed: r.bed,
      bedName: r.bed?.name ?? '',
      totalAllocated: 0,
      originalQty: r.quantity,
    }));

    let maxDay = 0;
    const bedLastDay: { [bedName: string]: number } = {};

    table.forEach((row, index) => {
      const size = row.size;
      const bed = row.bed;
      const bedName = bed?.name ?? '';
      const dailyCap = bed.capacityPerDay?.[size] ?? 0;

      let day = bedLastDay[bedName] ?? 1;

      while (row.remaining > 0 && day <= maxDays) {
        const dayKey = `d${day}`;
        let allocatedToday = 0;
        for (let i = 0; i < index; i++) {
          const prev = table[i];
          if (prev.bed.name === bedName && prev.size === size) {
            allocatedToday += prev[dayKey] ?? 0;
          }
        }

        const remainingCapacity = dailyCap - allocatedToday;

        if (remainingCapacity > 0) {
          const allocate = Math.min(row.remaining, remainingCapacity);
          row[dayKey] = (row[dayKey] ?? 0) + allocate;
          row.remaining -= allocate;
          row.totalAllocated += allocate;
          if (day > maxDay) maxDay = day;
          if (!bedLastDay[bedName] || day > bedLastDay[bedName]) {
            bedLastDay[bedName] = day;
          }
        }

        day++;
      }
    });

    // table.forEach((row) => {
    //   delete row.remaining;
    //   delete row.size;
    //   row.bed = row.bedName;
    //   delete row.bedName;
    // });

    // const allDays = Array.from({ length: maxDay }, (_, i) => `d${i + 1}`);
    // this.dayColumns = allDays.filter((d) => table.some((row) => (row[d] ?? 0) > 0));
    // this.tableRows = table;
    const warnings: typeof this.overCapacityWarnings = [];
    const validRows: any[] = [];

    table.forEach((row) => {
      if (row.totalAllocated === 0) {
        warnings.push({
          project: row.project,
          product: row.product,
          bed: row.bedName,
          requestedQty: row.qty,
        });
        return;
      }

      const scheduled = row.totalAllocated;
      const original = row.originalQty;

      const totalEnteredForThis = this.planRows
        .filter((r) => r.project === row.project && `${r.type} ${r.size}` === row.product)
        .reduce((sum, r) => sum + r.quantity, 0);

      const projectElemQty =
        this.projects
          ?.find((p: any) => p.name === row.project)
          ?.elements?.find((e: any) => `${e.type} ${e.size}` === row.product)?.quantity ?? original;


          
      row.scheduledQty = scheduled;
      row.totalEntered = totalEnteredForThis;
      row.projectElemQty = projectElemQty;
      row.remaining = projectElemQty - totalEnteredForThis;
      row.unscheduled = original - scheduled;
      delete row.remaining;
      delete row.size;
      delete row.totalAllocated;
      delete row.originalQty;
      row.bed = row.bedName;
      delete row.bedName;
      validRows.push(row);
    });

    this.overCapacityWarnings = warnings;

    const allDays = Array.from({ length: maxDay }, (_, i) => `d${i + 1}`);
    this.dayColumns = allDays.filter((d) => validRows.some((row) => (row[d] ?? 0) > 0));
    this.tableRows = validRows;
  }


//working but shows 0 %
// allocateProduction() {
//   const maxDays = 20;

 
//   const table: any[] = this.planRows.map(r => ({
//     id: r.id,
//     project: r.project,
//     product: `${r.type} ${r.size}`,
//     size: r.size,
//     qty: r.quantity,
//     remaining: r.quantity,
//     bed: r.bed,
//     bedName: r.bed?.name ?? '',
//     totalAllocated: 0
//   }));

//   let maxDay = 0;
//   const bedLastDay: { [bedName: string]: number } = {};

  
//   table.forEach((row, index) => {
//     const size = row.size;
//     const bedName = row.bedName;
//     const dailyCap = row.bed?.capacityPerDay?.[size] ?? 0;

//     let day = 1; 

//     while (row.remaining > 0 && day <= maxDays) {
//       const dayKey = `d${day}`;
      
//       let allocatedToday = table
//         .slice(0, index)
//         .filter(r => r.bedName === bedName && r.size === size)
//         .reduce((sum, r) => sum + (r[dayKey] ?? 0), 0);

//       const remainingCapacity = dailyCap - allocatedToday;

//       if (remainingCapacity > 0) {
//         const allocate = Math.min(row.remaining, remainingCapacity);
//         row[dayKey] = (row[dayKey] ?? 0) + allocate;
//         row.remaining -= allocate;
//         row.totalAllocated += allocate;
//         if (day > maxDay) maxDay = day;
//       }

//       day++;
//     }
//   });


//   const warnings: typeof this.overCapacityWarnings = [];
//   const validRows: any[] = [];

//   table.forEach(row => {
//     if (row.totalAllocated === 0) {
//       warnings.push({
//         project: row.project,
//         product: row.product,
//         bed: row.bedName,
//         requestedQty: row.qty
//       });
//       return;
//     }
//     row.bed = row.bedName;
//     delete row.remaining;
//     delete row.size;
//     delete row.totalAllocated;
//     row.bedName = undefined;
//     validRows.push(row);
//   });

//   this.overCapacityWarnings = warnings;
//   this.dayColumns = Array.from({ length: maxDay }, (_, i) => `d${i + 1}`);
//   this.tableRows = validRows;
// }
  
  // deleteRow(index: number) {
  //   this.planRows.splice(index, 1);
  //   this.allocateProduction();
  // }
// deleteRow(index: number) {
 
//   this.planRows.splice(index, 1);
//   const rowToDelete = this.filteredRows[index];
//   const planIndex = this.planRows.findIndex(
//     r => r.project === rowToDelete.project &&
//          `${r.type} ${r.size}` === rowToDelete.product &&
//          r.bed?.name === rowToDelete.bed
//   );
//   if (planIndex !== -1) {
//     this.planRows.splice(planIndex, 1);
//   }
//   this.allocateProduction();
// }


//working
// allocateProduction() {
//   const maxDays = 20;

//   // Build fresh table from planRows
//   const table: any[] = this.planRows.map(r => ({
//     id: r.id,
//     project: r.project,
//     product: `${r.type} ${r.size}`,
//     size: r.size,
//     qty: r.quantity,
//     remaining: r.quantity,
//     bed: r.bed,
//     bedName: r.bed?.name ?? '',
//     totalAllocated: 0,
//     originalQty: r.quantity
//   }));

//   let maxDay = 0;

//   // Reset bed allocation tracking
//   const bedLastDay: { [bedName: string]: number } = {};

//   // Allocate each row
//   table.forEach((row, index) => {
//     const size = row.size;
//     const bedName = row.bedName;
//     const dailyCap = row.bed?.capacityPerDay?.[size] ?? 0;

//     let day = 1; // always start from day 1 for allocation

//     while (row.remaining > 0 && day <= maxDays) {
//       const dayKey = `d${day}`;

//       // Sum previous allocations for same bed & size on this day
//       let allocatedToday = table
//         .slice(0, index)
//         .filter(r => r.bedName === bedName && r.size === size)
//         .reduce((sum, r) => sum + (r[dayKey] ?? 0), 0);

//       const remainingCapacity = dailyCap - allocatedToday;

//       if (remainingCapacity > 0) {
//         const allocate = Math.min(row.remaining, remainingCapacity);
//         row[dayKey] = (row[dayKey] ?? 0) + allocate;
//         row.remaining -= allocate;
//         row.totalAllocated += allocate;
//         if (day > maxDay) maxDay = day;
//       }

//       day++;
//     }
//   });

//   const warnings: typeof this.overCapacityWarnings = [];
//   const validRows: any[] = [];

//   table.forEach(row => {
//     if (row.totalAllocated === 0) {
//       warnings.push({
//         project: row.project,
//         product: row.product,
//         bed: row.bedName,
//         requestedQty: row.qty
//       });
//     }

//     const totalEnteredForThis = this.planRows
//       .filter(r => r.project === row.project && `${r.type} ${r.size}` === row.product)
//       .reduce((sum, r) => sum + r.quantity, 0);

//     const projectElemQty =
//       this.projects
//         ?.find((p: any) => p.name === row.project)
//         ?.elements?.find((e: any) => `${e.type} ${e.size}` === row.product)?.quantity ?? row.originalQty;

//     row.scheduledQty = row.totalAllocated;
//     row.totalEntered = totalEnteredForThis;
//     row.projectElemQty = projectElemQty;
//     row.remaining = projectElemQty - totalEnteredForThis;
//     row.unscheduled = row.originalQty - row.totalAllocated;

//     delete row.size;
//     delete row.totalAllocated;
//     delete row.originalQty;

//     row.bed = row.bedName;
//     delete row.bedName;

//     validRows.push(row);
//   });

//   this.overCapacityWarnings = warnings;

//   const allDays = Array.from({ length: maxDay }, (_, i) => `d${i + 1}`);
//   this.dayColumns = allDays.filter(d => validRows.some(row => (row[d] ?? 0) > 0));

//   this.tableRows = validRows;
// }





deleteRow(index: number) {

  const rowToDelete = this.filteredRows[index];
  if (!rowToDelete) return;
   this.rowDeleted.emit(rowToDelete.id);
  this.planRows = this.planRows.filter(r => r.id !== rowToDelete.id);
  this.allocateProduction();
}

  downloadExcel() {
    const data = this.tableRows.map((row) => {
      const obj: any = {
        Project: row.project,
        Product: row.product,
        Bed: row.bed,
        Quantity: row.qty,
      };

      this.dayColumns.forEach((day) => {
        obj[day.toUpperCase()] = row[day] || '';
      });

      return obj;
    });

    const worksheet: any = XLSX.utils.json_to_sheet(data);

    worksheet['!cols'] = [
      { wch: 15 }, // Project
      { wch: 30 }, // Product
      { wch: 10 }, // Bed
      { wch: 10 }, // Quantity
      ...this.dayColumns.map(() => ({ wch: 8 })),
    ];

    const range = XLSX.utils.decode_range(worksheet['!ref']);

    for (let col = range.s.c; col <= range.e.c; col++) {
      const cellAddress = XLSX.utils.encode_cell({ r: 0, c: col });

      if (!worksheet[cellAddress]) continue;

      worksheet[cellAddress].s = {
        font: { bold: true, color: { rgb: 'FFFFFF' } },
        fill: { fgColor: { rgb: '09ACD6' } }, // blue background
        alignment: { horizontal: 'center' },
      };
    }

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Production Plan');

    XLSX.writeFile(workbook, 'Production_Plan.xlsx');
  }

 get filteredRows() {
  if (!this.tableRows?.length) return []; 

  if (!this.searchText?.trim()) return this.tableRows;

  const search = this.searchText.toLowerCase().trim();

  return this.tableRows.filter(row => {
    return (
      row.project?.toLowerCase().includes(search) ||
      row.product?.toLowerCase().includes(search) ||
      row.bed?.toLowerCase().includes(search) ||
      row.qty?.toString().includes(search) ||
      this.dayColumns.some(day => row[day]?.toString().includes(search))
    );
  });
}

trackByIndex(index: number) {
  return index;
}
}
