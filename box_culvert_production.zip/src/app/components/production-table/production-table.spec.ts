import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductionTable } from './production-table';

describe('ProductionTable', () => {
  let component: ProductionTable;
  let fixture: ComponentFixture<ProductionTable>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProductionTable]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProductionTable);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
