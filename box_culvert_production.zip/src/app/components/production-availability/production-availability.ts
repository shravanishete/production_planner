import { CommonModule } from '@angular/common';
import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-production-availability',
  imports: [CommonModule],
  standalone: true,
  templateUrl: './production-availability.html',
  styleUrl: './production-availability.css',
})
export class ProductionAvailability implements OnChanges {
  @Input() projects: any[] = [];
  @Input() beds: any[] = [];
  @Input() show: boolean = true;
  

  ngOnChanges(changes: SimpleChanges): void {
    
  }
  getCapacity(bed: any, size: string): number {
    return bed.capacityPerDay?.[size] ?? 0;
  }
}

