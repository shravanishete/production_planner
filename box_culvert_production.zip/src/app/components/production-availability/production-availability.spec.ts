import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductionAvailability } from './production-availability';

describe('ProductionAvailability', () => {
  let component: ProductionAvailability;
  let fixture: ComponentFixture<ProductionAvailability>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProductionAvailability]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProductionAvailability);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
