import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GanttProduction } from './gantt-production';

describe('GanttProduction', () => {
  let component: GanttProduction;
  let fixture: ComponentFixture<GanttProduction>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GanttProduction]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GanttProduction);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
