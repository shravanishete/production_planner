import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
  selector: 'app-gantt-production',
  standalone: true,
  imports: [CommonModule, MatIconModule,MatTooltipModule],
  templateUrl: './gantt-production.html',
  styleUrl: './gantt-production.css',
})
export class GanttProduction {
  @Input() tableRows: any[] = [];
  @Input() dayColumns: string[] = [];
  @Output() close = new EventEmitter<void>();
hoveredRow: any = null;
  readonly dayWidth = 70;
ngOnInit() {
  console.log(this.tableRows);
}
  private readonly BED_PALETTE: { [key: string]: string } = {
    'Bed 1': '#7c3aed',
    'Bed 2': '#0891b2',
    'Bed 3': '#7c3aed',
    'Bed 4': '#059669',
    'Bed 5': '#d97706',
  };

  private readonly FALLBACK_COLORS = [
    '#2563eb', '#0891b2', '#7c3aed', '#059669', '#d97706', '#db2777'
  ];

  get bedColors(): { name: string; color: string }[] {
    const seen = new Set<string>();
    return this.tableRows
      .map(r => r.bed)
      .filter(b => { if (seen.has(b)) return false; seen.add(b); return true; })
      .map(b => ({ name: b, color: this.getBedColor(b) }));
  }

  getBedColor(bedName: string): string {
    if (this.BED_PALETTE[bedName]) return this.BED_PALETTE[bedName];
    
    let hash = 0;
    for (let i = 0; i < bedName.length; i++) hash = bedName.charCodeAt(i) + ((hash << 5) - hash);
    return this.FALLBACK_COLORS[Math.abs(hash) % this.FALLBACK_COLORS.length];
  }

  getBedGradient(bedName: string): string {
    const c = this.getBedColor(bedName);
    return `linear-gradient(135deg, ${c}dd, ${c})`;
  }

  goBack() {
    this.close.emit();
  }
getCompletionPercentage(row: any): number {
  const totalAvailable = row.projectElemQty; 

  if (!totalAvailable || totalAvailable === 0) return 0;

  const producedQty = this.dayColumns.reduce(
    (sum, day) => sum + (row[day] || 0),
    0
  );

  return Math.round((producedQty / totalAvailable) * 100);
}
//   getCompletionPercentage(row: any): number {
//   const totalQty = row.qty;
//   if (!totalQty || totalQty === 0) return 0;

//   const producedQty = this.dayColumns.reduce(
//     (sum, day) => sum + (row[day] || 0),
//     0
//   );

//   return Math.min(100, Math.round((producedQty / totalQty) * 100));
// }

// added
getStartDayIndex(row: any): number {
  for (let i = 0; i < this.dayColumns.length; i++) {
    if (row[this.dayColumns[i]] > 0) return i;
  }
  return 0;
}

getDuration(row: any): number {
  return this.dayColumns.filter(day => row[day] > 0).length;
}

getTooltipText(row: any): string {
  const daysInfo = this.dayColumns
    .filter(day => row[day] > 0)
    .map(day => `Day ${day.replace('d','')}: ${row[day]} units`)
    .join('\n');

  // return `${row.project}\n${row.product}\n\n${daysInfo}`;
  return `${daysInfo}`;
}
// added
// Group rows by project+product key
getGroupKey(row: any): string {
  return `${row.project}||${row.product}`;
}

// Check if this row is the LAST in its group
isLastInGroup(row: any, index: number): boolean {
  const key = this.getGroupKey(row);
  const nextRow = this.tableRows[index + 1];
  return !nextRow || this.getGroupKey(nextRow) !== key;
}

// Total allocated qty across all rows in the same group
getGroupTotalAllocated(row: any): number {
  return this.tableRows
    .filter(r => this.getGroupKey(r) === this.getGroupKey(row))
    .reduce((sum, r) => sum + this.dayColumns.reduce((s, d) => s + (r[d] || 0), 0), 0);
}

// Summary % for the group (combined)
getGroupCompletionPct(row: any): number {
  const total = row.projectElemQty;
  if (!total) return 0;
  return Math.min(100, Math.round((this.getGroupTotalAllocated(row) / total) * 100));
}

// Remaining % for ghost bar
getGroupRemainingPct(row: any): number {
  return Math.max(0, 100 - this.getGroupCompletionPct(row));
}

// Summary bar span: from first active day of group to last
getGroupStartIndex(row: any): number {
  const groupRows = this.tableRows.filter(r => this.getGroupKey(r) === this.getGroupKey(row));
  for (let i = 0; i < this.dayColumns.length; i++) {
    if (groupRows.some(r => r[this.dayColumns[i]] > 0)) return i;
  }
  return 0;
}

getGroupDuration(row: any): number {
  const groupRows = this.tableRows.filter(r => this.getGroupKey(r) === this.getGroupKey(row));
  let last = -1;
  for (let i = 0; i < this.dayColumns.length; i++) {
    if (groupRows.some(r => r[this.dayColumns[i]] > 0)) last = i;
  }
  const start = this.getGroupStartIndex(row);
  return last >= start ? last - start + 1 : 0;
}
}